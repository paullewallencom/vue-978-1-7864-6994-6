run

    npm install
    npm run build

and open index.html in browser
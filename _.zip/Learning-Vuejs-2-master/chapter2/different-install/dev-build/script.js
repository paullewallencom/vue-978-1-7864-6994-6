var Vue = require('vue/dist/vue.js');

var data = {
  message: 'Learning Vue.js'
};

new Vue({
  el: '#app',
  data: data
});
<template>
  <div class="well">
    <img :src="catImgSrc" />
  </div>
</template>

<style scoped>
</style>

<script>
</script>

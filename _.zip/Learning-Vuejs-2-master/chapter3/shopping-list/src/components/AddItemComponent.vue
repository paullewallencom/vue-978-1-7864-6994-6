<template>
  <div>
    <div class="input-group">
      <input type="text" class="input form-control" placeholder="add shopping list item">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button">Add!</button>
      </span>
    </div>
  </div>
</template>

<script>
  export default {}
</script>

<style scoped>
</style>

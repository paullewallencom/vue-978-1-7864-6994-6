<template>
  <div>
    <h3>{{ title }}</h3>
    <!--<p>-->
      <!--{{ Math.pow(5, 2) }}-->
    <!--</p>-->
  </div>
</template>

<style scoped>
</style>

<script>
  export default {
    data () {
      return {
        title: 'Learning Vue.js!'
      }
    }
  }
</script>


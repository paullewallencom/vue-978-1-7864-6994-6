<template>
  <div>
    <em>Change the title of your shopping list here</em>
    <input/>
  </div>
</template>

<script>
  export default {
  }
</script>

<style scoped>
</style>

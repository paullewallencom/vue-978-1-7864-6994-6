export const WORKING_TIME = 20 * 60
export const RESTING_TIME = 5 * 60
